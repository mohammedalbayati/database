<?php
 ob_start();
 session_start();
 require_once '../database/dbconnect.php';

 // if session is not set this will redirect to login page

 if( !isset($_SESSION['user']) ) {
  header("Location: ../user_log_reg/index.php");

  exit;
}

if($_POST) {

    $intname = $_POST['interval_name'];
    $intdescription = $_POST['interval_description'];
    $intlength = $_POST['length'];
    $intcolor = $_POST['interval_color'];
    $userSession = $_SESSION['user'];

    $sql = "INSERT INTO intervals (interval_name, interval_description, length, interval_color, fk_user_id) VALUES ('$intname', '$intdescription', '$intlength', '$intcolor', '$userSession')";

    if($connect->query($sql) === TRUE) {
        echo "<p>New Record Successfully Created</p>";
        echo "<a href='../int_crud/int_create.php'><button type='button'>Back</button></a>";
        echo "<a href='../user_log_reg/index.php'><button type='button'>Home</button></a>";

    } else {
        echo "Error " . $sql . ' ' . $connect->connect_error;

    }

    $connect->close();

}


?>
<?php ob_end_flush(); ?>