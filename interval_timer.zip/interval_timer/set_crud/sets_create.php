<!DOCTYPE html>
<html>
<head>

    <title>PHP CRUD  |  Add Set</title>

</head>
<body>

 

<fieldset>
    <legend>Add Set</legend>

 

    <form action="../set_actions/set_create.php" method="post">
        <table cellspacing="0" cellpadding="0">
            <tr>

                <th>Set Name</th>
                <td><input type="text" name="set_name" placeholder="Set Name" /></td>

            </tr>     
            <tr>

                <th>Set Description</th>
                <td><input type="text" name="set_description" placeholder="Description" /></td>

            </tr>
            <tr>

                <td><button type="submit">Insert set</button></td>
                <td><a href="index.php"><button type="button">Back</button></a></td>

            </tr>
        </table>
    </form>

 

</fieldset>

</body>
</html>