<?php

require_once 'database/dbconnect.php';


if($_POST) {

    $sname = $_POST['set_name'];
    $sdescription = $_POST['set_description'];

    $id = $_POST['id'];

    $sql = "UPDATE sets SET set_name = '$sname', set_description = '$sdescription' WHERE set_id = {$id}";

    if($connect->query($sql) === TRUE) {

        echo "<p>Succcessfully Updated</p>";
        echo "<a href='../update.php?id=".$id."'><button type='button'>Back</button></a>";
        echo "<a href='../index.php'><button type='button'>Home</button></a>";

    } else {
        echo "Erorr while updating record : ". $connect->error;

    }

    $connect->close();

}

?>