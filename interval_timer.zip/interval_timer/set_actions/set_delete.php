<?php

require_once 'database/dbconnect.php';

if($_POST) {

    $sname = $_POST['set_name'];
    $sdescription = $_POST['set_description'];


    $sql = "INSERT INTO sets (set_name, set_description) VALUES ('$sname', '$sdescription')";

    if($connect->query($sql) === TRUE) {
        echo "<p>New Record Successfully Created</p>";
        echo "<a href='../create.php'><button type='button'>Back</button></a>";
        echo "<a href='../index.php'><button type='button'>Home</button></a>";

    } else {
        echo "Error " . $sql . ' ' . $connect->connect_error;

    }

    $connect->close();

}

?>