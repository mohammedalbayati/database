<?php require_once 'database/dbconnect.php'; ?>

<!DOCTYPE html>
<html>
<head>

    <title>PHP CRUD</title>

</head>
<body>

    <a href="create.php"><button type="button">Add User</button></a>

    <!-- User Table -->
    <table border="1" cellspacing="0" cellpadding="0">
        <thead>

            <tr>
                <th>User Name</th>
                <th>User Email</th>
                <th>Option</th>
            </tr>

        </thead>
        <tbody>

            <?php
            $sql = "SELECT * FROM users";
            $result = $connect->query($sql);

 

            if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {

                    echo "<tr>
                        <td>".$row['user_name']."</td>
                        <td>".$row['user_email']."</td>
                        <td>

                            <a href='update.php?id=".$row['user_id']."'><button type='button'>Edit</button></a>
                            <a href='delete.php?id=".$row['user_id']."'><button type='button'>Delete</button></a>

                        </td>
                    </tr>";
                }

            } else {
                echo "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
            }

            ?>


             

        </tbody>
    </table>
    <br>
    
    <!-- Sets table -->
    <a href="set_crud/sets_create.php"><button type="button">Add Set</button></a>
    <table border="1" cellspacing="0" cellpadding="0">
        <thead>

            <tr>
                <th>Set Name</th>
                <th>Set Description</th>
                <th>Option</th>
            </tr>

        </thead>
        <tbody>

            <?php
            $sql = "SELECT * FROM sets";
            $result = $connect->query($sql);

 

            if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {

                    echo "<tr>
                        <td>".$row['set_name']."</td>
                        <td>".$row['set_description']."</td>
                        <td>

                            <a href='update.php?id=".$row['set_id']."'><button type='button'>Edit</button></a>
                            <a href='delete.php?id=".$row['set_id']."'><button type='button'>Delete</button></a>

                        </td>
                    </tr>";
                }

            } else {
                echo "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
            }

            ?>


             

        </tbody>
    </table>


</body>
</html>